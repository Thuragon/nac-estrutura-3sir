﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfApplication2
{
    public class Plotagem
    {
        public List<Aluno> listaDeAlunos;
        private List<int> _localPlotadoX = new List<int>();
        private List<int> _localPlotadoY = new List<int>();


        public Plotagem(List<Aluno> listaAlunos)
        {
            this.listaDeAlunos = listaAlunos;
        }


        public void GerarCoordenadas()
        {
            Random rnd = new Random();
            int x, y;
            x = rnd.Next(1000);
            y = rnd.Next(1000);
            _localPlotadoX.Add(x);
            _localPlotadoY.Add(y);

            do
            {
                x = rnd.Next(1000);
                y = rnd.Next(1000);
                for (int k = 0; k < _localPlotadoX.Count; k++)
                {
                    if (x > _localPlotadoX[k] - 50 && x < _localPlotadoX[k] + 50 && y > _localPlotadoY[k] - 50 && y < _localPlotadoY[k] + 50)
                    {
                        k = -1;
                        x = rnd.Next(1000);
                        y = rnd.Next(1000);
                    }
                }
                _localPlotadoX.Add(x);
                _localPlotadoY.Add(y);

            } while (_localPlotadoX.Count < listaDeAlunos.Count && _localPlotadoY.Count < listaDeAlunos.Count);
        }

        public List<int> Plotar()
        {
            GerarCoordenadas();
            List<int> retorno = new List<int>();
            retorno.Add(_localPlotadoX[0]);
            retorno.Add(_localPlotadoY[0]);
            _localPlotadoX.Remove(_localPlotadoX[0]);
            _localPlotadoY.Remove(_localPlotadoY[0]);
            return retorno;
        }
    }
}

