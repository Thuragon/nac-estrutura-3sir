﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfApplication2
{
    public class Aluno
    {
        public string rm;
        public List<string> amigos = new List<string>();
        public int coordenadaX = 0;
        public int coordenadaY = 0;

        public Aluno()
        {
 
        }

    }
}
