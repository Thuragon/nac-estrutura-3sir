﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.IO.Compression;


namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Aluno> _listaAlunos;
        private List<Button> _listaBotoes = new List<Button>();

        public MainWindow()
        {
            InitializeComponent();
            _listaAlunos = new List<Aluno>();
        }

        private void Console_Scroll(object sender, System.Windows.Controls.Primitives.ScrollEventArgs e)
        {

        }

        private void Button_Importar(object sender, RoutedEventArgs e)
        {
            LerArquivoTexto();
            Plotagem plotagem = new Plotagem(_listaAlunos);
            List<int> coordenadas = new List<int>();
            Busca busca = new Busca(_listaAlunos);
            Aluno aluno = new Aluno();

            for (int i = 0; i < _listaAlunos.Count; i++)
            {
                Button b = new Button();
                b.Style = (Style)(this.Resources["BotaoVermelho"]);
                coordenadas = plotagem.Plotar();
                _listaAlunos[i].coordenadaX = coordenadas[0];
                _listaAlunos[i].coordenadaY = coordenadas[1];
                b.Margin = new Thickness(_listaAlunos[i].coordenadaX, _listaAlunos[i].coordenadaY, 0, 0);
                b.Name = "rm" + _listaAlunos[i].rm.ToString();
                ConsoleCanvas.Children.Add(b);
                coordenadas.RemoveRange(0, coordenadas.Count);
                _listaBotoes.Add(b);
                b.ToolTip = "rm" + _listaAlunos[i].rm.ToString();

                Canvas.SetZIndex(b, 999);
            }

            for (int i = 0; i < _listaAlunos.Count; i++)
            {
                for (int k = 0; k < _listaAlunos[i].amigos.Count; k++)
                {
                    aluno = busca.BuscarAlunoNaLista(_listaAlunos[i].amigos[k]);

                    if (_listaAlunos.Contains(aluno))
                    {
                        Line linha = new Line();
                        linha.Stroke = System.Windows.Media.Brushes.Black;
                        linha.X1 = _listaAlunos[i].coordenadaX + 10;
                        linha.Y1 = _listaAlunos[i].coordenadaY + 10;
                        linha.X2 = aluno.coordenadaX + 10;
                        linha.Y2 = aluno.coordenadaY + 10;
                        linha.StrokeThickness = 1;
                        ConsoleCanvas.Children.Add(linha);
                    }
                }
            }
        }

        private void LerArquivoTexto()
        {
            // cria um OpenFileDialog
            if (_listaAlunos.Count > 0)
            {
                _listaAlunos.RemoveRange(0, _listaAlunos.Count);
                ConsoleCanvas.Children.Clear();
            }
            OpenFileDialog abriArquivo = new OpenFileDialog();
            abriArquivo.DefaultExt = ".txt";
            abriArquivo.Filter = "txt files (*.txt)|*.txt| arquivos zip (*.zip)|*.zip";
            abriArquivo.FilterIndex = 1;
            abriArquivo.Multiselect = true;

            Nullable<bool> resultado = abriArquivo.ShowDialog();

            if (resultado == true)
            {
                try
                {
                    string linha = null;
                    foreach (string fileName in abriArquivo.FileNames)
                    {
                        StreamReader str = new StreamReader(fileName);
                        string nomeDoArquivo = fileName.Substring(fileName.LastIndexOf("\\") + 1, fileName.Length - 5 - fileName.LastIndexOf("\\"));
                        Aluno aluno = new Aluno();
                        aluno.rm = nomeDoArquivo;
                        while ((linha = str.ReadLine()) != null)
                        {
                            string[] amigo = linha.Replace(" ", "").Split(',');
                            for (int i = 0; i < amigo.Count(); i++)
                                aluno.amigos.Add(amigo[i]);
                        }

                        _listaAlunos.Add(aluno);
                        str.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Nao foi possivel ler o arquivo do disco:  " + ex.Message);
                }
            }
        }

        public void Imprimir(List<Aluno> listaAlunos)
        {
            for (int i = 0; i < listaAlunos.Count; i++)
            {
                TextBoxLista.Text += "Aluno: " + listaAlunos[i].rm + "\nAmigos do aluno:\n";
                for (int j = 0; j < listaAlunos[i].amigos.Count; j++)
                {
                    TextBoxLista.Text += listaAlunos[i].amigos[j].ToString() + "\n";
                }
            }
        }

        private void Button_BuscarMenorDistancia(object sender, RoutedEventArgs e)
        {
            PlotarNaTela();
            Busca novabusca = new Busca(_listaAlunos);
            List<Aluno> mostrar = new List<Aluno>();
            try
            {
                mostrar = novabusca.BuscarMenorDistancia(TextBoxAlunoOrigem.Text, TextBoxAlunoDestino.Text);
                if (mostrar == null)
                {
                    MessageBox.Show("é impossivel que estes alunos se comuniquem");
                }
                else
                {
                    if (TextBoxLista.Text.Length > 0)
                        TextBoxLista.Text += "\n\n";
                    TextBoxLista.Text += "Menor Caminho é:\n";
                    for (int i = mostrar.Count - 1; i >= 0; i--)
                    {
                        TextBoxLista.Text += mostrar[i].rm;
                        if (i != 0)
                            TextBoxLista.Text += "-> ";
                    }

                    for (int i = 0; i < mostrar.Count; i++)
                    {
                        for (int k = 0; k < _listaBotoes.Count; k++)
                        {
                            if (_listaBotoes[k].Name.Equals("rm" + mostrar[i].rm))
                            {
                                _listaBotoes[k].Background = Brushes.Green;
                                if (i == 0)
                                    _listaBotoes[k].Background = Brushes.DarkGreen;
                                if (i == mostrar.Count - 1)
                                    _listaBotoes[k].Background = Brushes.YellowGreen;
                            }
                        }
                    }

                    for (int i = 0; i < mostrar.Count - 1; i++)
                    {
                        Line linha = new Line();
                        linha.Stroke = System.Windows.Media.Brushes.Green;
                        linha.X1 = mostrar[i].coordenadaX + 10;
                        linha.Y1 = mostrar[i].coordenadaY + 10;
                        if (i < mostrar.Count - 1)
                        {
                            linha.X2 = mostrar[i + 1].coordenadaX + 10;
                            linha.Y2 = mostrar[i + 1].coordenadaY + 10;
                            linha.StrokeThickness = 2;
                            ConsoleCanvas.Children.Add(linha);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Incontactaveis(object sender, RoutedEventArgs e)
        {
            PlotarNaTela();
            Busca busca = new Busca(_listaAlunos);
            List<Aluno> incontactaveis = new List<Aluno>();
            incontactaveis = busca.Incontactaveis(TextBoxIncontactaveis.Text);
            if (TextBoxLista.Text.Length > 0)
                TextBoxLista.Text += "\n\n";
            TextBoxLista.Text += "Os alunos incontactaveis sao: \n";
            for (int i = 0; i < incontactaveis.Count; i++)
            {
                TextBoxLista.Text += incontactaveis[i].rm;
                if (i < incontactaveis.Count - 1)
                    TextBoxLista.Text += ", ";
            }

            for (int i = 0; i < incontactaveis.Count; i++)
            {
                for (int k = 0; k < _listaBotoes.Count; k++)
                {
                    if (_listaBotoes[k].Name.Equals("rm" + incontactaveis[i].rm))
                    {
                        _listaBotoes[k].Background = Brushes.Green;
                    }
                }
            }

        }

        private void Button_Intermediarios(object sender, RoutedEventArgs e)
        {
            PlotarNaTela();
            Busca busca = new Busca(_listaAlunos);
            List<Aluno> intermediarios = new List<Aluno>();
            intermediarios = busca.Intermediarios(TextBoxIntermediarios.Text);
            if (TextBoxLista.Text.Length > 0)
                TextBoxLista.Text += "\n\n";
            TextBoxLista.Text += "Os alunos que agem como intermediarios sao: \n";
            for (int i = 0; i < intermediarios.Count; i++)
            {
                TextBoxLista.Text += intermediarios[i].rm;
                if (i < intermediarios.Count - 1)
                    TextBoxLista.Text += ", ";
            }
            for (int i = 0; i < intermediarios.Count; i++)
            {
                for (int k = 0; k < _listaBotoes.Count; k++)
                {
                    if (_listaBotoes[k].Name.Equals("rm" + intermediarios[i].rm))
                    {
                        _listaBotoes[k].Background = Brushes.Green;
                    }
                }
            }
        }

        private void Button_BuscarNaRange(object sender, RoutedEventArgs e)
        {
            PlotarNaTela();
            int range;
            if (Int32.TryParse(TextBoxRange.Text, out range))
            {
                if (range < 1 || range > 5)
                    MessageBox.Show("Range invalido: favor digitar um range entre 1 e 5");
                else
                {
                    Busca buscar = new Busca(_listaAlunos);
                    List<Aluno> comunicaveisNaRange = new List<Aluno>();

                    if (buscar.BuscarAlunoNaLista(TextBoxAlunoRange.Text).rm == null)
                    {
                        MessageBox.Show("Aluno inexistente");
                    }
                    else
                    {
                        if (TextBoxLista.Text.Length > 0)
                        {
                            TextBoxLista.Text += "\n\n";
                        }

                        comunicaveisNaRange = buscar.BuscarNaRange(TextBoxAlunoRange.Text, range);
                        TextBoxLista.Text += "Os alunos comunicaveis até a range " + range + " são:\n";
                        for (int i = 1; i < comunicaveisNaRange.Count; i++)
                        {
                            TextBoxLista.Text += comunicaveisNaRange[i].rm;
                            if (i < comunicaveisNaRange.Count - 1)
                                TextBoxLista.Text += "\n";
                        }

                        for (int i = 0; i < comunicaveisNaRange.Count; i++)
                        {
                            for (int k = 0; k < _listaBotoes.Count; k++)
                            {
                                if (_listaBotoes[k].Name.Equals("rm" + comunicaveisNaRange[i].rm))
                                {
                                    _listaBotoes[k].Background = Brushes.Green;
                                    if (i == 0)
                                        _listaBotoes[k].Background = Brushes.YellowGreen;
                                }
                            }
                        }
                        comunicaveisNaRange = buscar.BuscarNaRange(TextBoxAlunoRange.Text, range - 1);
                        Aluno aluno = new Aluno();
                        for (int i = 0; i < comunicaveisNaRange.Count; i++)
                        {

                            for (int k = 0; k < comunicaveisNaRange[i].amigos.Count; k++)
                            {
                                aluno = buscar.BuscarAlunoNaLista(comunicaveisNaRange[i].amigos[k]);
                                if (_listaAlunos.Contains(aluno))
                                {
                                    Line linha = new Line();
                                    linha.Stroke = System.Windows.Media.Brushes.Green;
                                    linha.X1 = comunicaveisNaRange[i].coordenadaX + 10;
                                    linha.Y1 = comunicaveisNaRange[i].coordenadaY + 10;
                                    linha.StrokeThickness = 2;
                                    linha.X2 = aluno.coordenadaX + 10;
                                    linha.Y2 = aluno.coordenadaY + 10;
                                    ConsoleCanvas.Children.Add(linha);
                                }
                            }
                            if (range - 1 == 0)
                                break;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Range invalido: favor digitar um range entre 1 e 5");
            }
        }

        private void Button_LimparInformacoes(object sender, RoutedEventArgs e)
        {
            TextBoxLista.Clear();
            ResetarBotoes();
            PlotarNaTela();
        }

        private void ResetarBotoes()
        {
            for (int i = 0; i < _listaBotoes.Count; i++)
            {
                _listaBotoes[i].Background = Brushes.Red;
            }
        }

        private void PlotarNaTela()
        {
            ConsoleCanvas.Children.Clear();
            Plotagem plotagem = new Plotagem(_listaAlunos);
            List<int> coordenadas = new List<int>();
            Busca busca = new Busca(_listaAlunos);
            Aluno aluno = new Aluno();

            for (int i = 0; i < _listaAlunos.Count; i++)
            {
                Button b = new Button();
                b.Style = (Style)(this.Resources["BotaoVermelho"]);
                coordenadas = plotagem.Plotar();
                _listaAlunos[i].coordenadaX = coordenadas[0];
                _listaAlunos[i].coordenadaY = coordenadas[1];
                b.Margin = new Thickness(_listaAlunos[i].coordenadaX, _listaAlunos[i].coordenadaY, 0, 0);
                b.Name = "rm" + _listaAlunos[i].rm.ToString();
                ConsoleCanvas.Children.Add(b);
                coordenadas.RemoveRange(0, coordenadas.Count);
                _listaBotoes.Add(b);
                b.ToolTip = "rm" + _listaAlunos[i].rm.ToString();

                Canvas.SetZIndex(b, 999);
            }

            for (int i = 0; i < _listaAlunos.Count; i++)
            {
                for (int k = 0; k < _listaAlunos[i].amigos.Count; k++)
                {
                    aluno = busca.BuscarAlunoNaLista(_listaAlunos[i].amigos[k]);

                    if (_listaAlunos.Contains(aluno))
                    {
                        Line linha = new Line();
                        linha.Stroke = System.Windows.Media.Brushes.Black;
                        linha.X1 = _listaAlunos[i].coordenadaX + 10;
                        linha.Y1 = _listaAlunos[i].coordenadaY + 10;
                        linha.X2 = aluno.coordenadaX + 10;
                        linha.Y2 = aluno.coordenadaY + 10;
                        linha.StrokeThickness = 1;
                        ConsoleCanvas.Children.Add(linha);
                    }
                }
            }
        }
    }
}







