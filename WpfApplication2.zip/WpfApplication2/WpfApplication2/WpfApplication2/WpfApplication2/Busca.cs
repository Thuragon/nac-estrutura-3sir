﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfApplication2
{
    public class Busca
    {
        private List<Aluno> _listaAlunos;

        public Busca(List<Aluno> alunos)
        {
            this._listaAlunos = alunos;
        }

        public Aluno BuscarAlunoNaLista(string rm)
        {
            Aluno retorno = new Aluno();
            for (int i = 0; i < _listaAlunos.Count; i++)
            {
                if (_listaAlunos[i].rm.Equals(rm))
                {
                    retorno = _listaAlunos[i];
                }
            }
            return retorno;
        }

        public List<Aluno> BuscarMenorDistancia(string rmOrigem, string rmdestino)
        {
            Aluno destino = BuscarAlunoNaLista(rmdestino);
            Aluno origem = BuscarAlunoNaLista(rmOrigem);
            if (origem.rm == null || destino.rm == null)
            {
                throw new Exception("Aluno Origem ou Destino Inexistente, digite 2 alunos validos");
            }

            else
            {
                int intermediarios = 0;
                List<Aluno> novaLista = new List<Aluno>();
                List<int> listaPosicoes = new List<int>();
                novaLista.Add(origem);
                int aux = 0;
                listaPosicoes.Add(aux);
                for (int i = 0; i < novaLista.Count; i++)
                {
                    for (int k = 0; k < novaLista[i].amigos.Count; k++)
                    {
                        if (novaLista[i].amigos[k] == rmdestino)
                        {
                            novaLista.Add(BuscarAlunoNaLista(novaLista[i].amigos[k]));
                            i = novaLista.Count;
                            break;
                        }
                        else if (!novaLista.Contains(BuscarAlunoNaLista(novaLista[i].amigos[k])))
                        {
                            if (BuscarAlunoNaLista(novaLista[i].amigos[k]).rm != null)
                            {
                                novaLista.Add(BuscarAlunoNaLista(novaLista[i].amigos[k]));
                            }
                        }
                    }

                    if (aux == i)
                    {
                        aux = novaLista.Count - 1;
                        intermediarios++;
                        listaPosicoes.Add(aux);
                    }
                }

                if (!novaLista.Contains(destino))
                {
                    return null;
                }

                List<Aluno> Mostrar = new List<Aluno>();
                Mostrar.Add(destino);
                for (int i = listaPosicoes.Last(); i >= 0; i--)
                {
                    if (novaLista[i].amigos.Contains(destino.rm))
                    {
                        Mostrar.Add(novaLista[i]);
                        destino = novaLista[i];
                        listaPosicoes.Remove(listaPosicoes.Last());
                        if (listaPosicoes.Count == 0)
                        {
                            i = 0; 
                        }
                        else
                        {
                            i = listaPosicoes.Last() +1 ;
                        }
                    }
                }

                return Mostrar;
            }
        }

        public List<Aluno> Incontactaveis(string rmAluno)
        {
            if (BuscarAlunoNaLista(rmAluno).rm == null)
            {
                throw new Exception("Aluno inexistente");
            }
            else
            {
                List<Aluno> novaLista = new List<Aluno>();
                novaLista.Add(BuscarAlunoNaLista(rmAluno));

                for (int i = 0; i < novaLista.Count; i++)
                {
                    for (int k = 0; k < novaLista[i].amigos.Count; k++)
                    {
                        if (!novaLista.Contains(BuscarAlunoNaLista(novaLista[i].amigos[k])) && BuscarAlunoNaLista(novaLista[i].amigos[k]).rm != null)
                        {
                            novaLista.Add(BuscarAlunoNaLista(novaLista[i].amigos[k]));
                        }
                    }
                }
                List<Aluno> incontactaveis = new List<Aluno>();
                for (int i = 0; i < _listaAlunos.Count; i++)
                {
                    if (!novaLista.Contains(_listaAlunos[i]))
                    {
                        incontactaveis.Add(_listaAlunos[i]);
                    }
                }
                return incontactaveis;
            }
        }

        public List<Aluno> Intermediarios(string rmAluno)
        {
            if (BuscarAlunoNaLista(rmAluno).rm == null)
            {
                throw new Exception("Aluno inexistente");
            }
            List<Aluno> circuloDeAmizade = new List<Aluno>();
            List<Aluno> intermediarios = new List<Aluno>();
            List<Aluno> compara = new List<Aluno>();
            circuloDeAmizade.Add(BuscarAlunoNaLista(rmAluno));
            for (int i = 0; i < circuloDeAmizade.Count; i++)
            {
                for (int k = 0; k < circuloDeAmizade[i].amigos.Count; k++)
                {
                    if (!circuloDeAmizade.Contains(BuscarAlunoNaLista(circuloDeAmizade[i].amigos[k])) && BuscarAlunoNaLista(circuloDeAmizade[i].amigos[k]).rm != null)
                    {
                        circuloDeAmizade.Add(BuscarAlunoNaLista(circuloDeAmizade[i].amigos[k]));
                    }
                }
            }

            for (int i = 1; i < circuloDeAmizade.Count; i++)
            {
                {
                    compara = PopulaListaAmigos(rmAluno, circuloDeAmizade[i].rm);
                    if (compara.Count < circuloDeAmizade.Count - 1)
                        intermediarios.Add(circuloDeAmizade[i]);
                }

            }
            return intermediarios;
        }

        public List<Aluno> PopulaListaAmigos(string rmAluno, string desconsiderarAluno)
        {
            List<Aluno> circuloDeAmizade = new List<Aluno>();
            circuloDeAmizade.Add(BuscarAlunoNaLista(rmAluno));

            for (int i = 0; i < circuloDeAmizade.Count; i++)
            {
                for (int k = 0; k < circuloDeAmizade[i].amigos.Count; k++)
                {
                    if (!circuloDeAmizade.Contains(BuscarAlunoNaLista(circuloDeAmizade[i].amigos[k])) && BuscarAlunoNaLista(circuloDeAmizade[i].amigos[k]).rm != null)
                    {
                        circuloDeAmizade.Add(BuscarAlunoNaLista(circuloDeAmizade[i].amigos[k]));
                        if (circuloDeAmizade.Last().rm.Equals(desconsiderarAluno))
                            circuloDeAmizade.Remove(circuloDeAmizade.Last());
                    }
                }
            }
            return circuloDeAmizade;
        }

        public List<Aluno> BuscarNaRange(string rmAluno, int range)
        {
            Aluno aluno = BuscarAlunoNaLista(rmAluno);
            List<Aluno> comunicaveisNaRange = new List<Aluno>();
            int aux = 0;
            comunicaveisNaRange.Add(aluno);
            for (int i = 0; i < comunicaveisNaRange.Count; i++)
            {
                for (int k = 0; k < comunicaveisNaRange[i].amigos.Count; k++)
                {
                    if (!comunicaveisNaRange.Contains(BuscarAlunoNaLista(comunicaveisNaRange[i].amigos[k])) &&
                        BuscarAlunoNaLista(comunicaveisNaRange[i].amigos[k]).rm != null)
                    {
                        comunicaveisNaRange.Add(BuscarAlunoNaLista(comunicaveisNaRange[i].amigos[k]));
                    }
                }

                if (aux == i)
                {
                    aux = comunicaveisNaRange.Count - 1;
                    range--;
                }
                if (range == 0)
                    break;
            }
            return comunicaveisNaRange;
        }
    }
}
